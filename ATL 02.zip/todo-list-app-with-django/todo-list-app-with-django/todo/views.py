from django.shortcuts import render, redirect, get_object_or_404
from .models import Todo

# View to display and add todos
def index(request):
    todos = Todo.objects.all()

    if request.method == 'POST':
        title = request.POST.get('title')
        if title: 
            Todo.objects.create(title=title)
        return redirect('/')

    return render(request, 'index.html', {'todos': todos})

# View primary key delete todo
def delete(request, pk):
    todo = get_object_or_404(Todo, pk=pk)
    todo.delete()
    return redirect('/')

def toggle_complete(request, pk):
    todo = get_object_or_404(Todo, pk=pk)
    todo.completed = not todo.completed
    todo.save()
    return redirect('/')